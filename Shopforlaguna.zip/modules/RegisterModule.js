const db = require('../core/db');

const ResRegistration = (data) => {
    var sql = `INSERT INTO td_contacts (id, contact_date, restaurant_name, contact_name, phone_no, email, addr_line1, addr_line2, city, zip, country, website, created_by, created_at) VALUES`;
}

module.exports = { ResRegistration };