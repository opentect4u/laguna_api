const express = require('express');
const { ResRegistration } = require('../modules/RegisterModule');
const RegRouter = express.Router();

RegRouter.post('/registration', async (req, res) => {
    const data = await ResRegistration(req.body);
    res.send({ data: 'Welcome' });
})

module.exports = { RegRouter };